<div class="table-responsive-sm">
    <table class="table table-striped " id="users-table">
        <thead>
            <th><?php echo app('translator')->get('models/users.fields.name'); ?></th>
            <th><?php echo app('translator')->get('models/users.fields.email'); ?></th>
            <th><?php echo app('translator')->get('models/users.fields.status'); ?></th>
            <th><?php echo app('translator')->get('models/users.fields.created_at'); ?></th>
            <th><?php echo app('translator')->get('crud.action'); ?></th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->status); ?></td>
                <td><?php echo e($user->created_at); ?></td>
                <td>
                    <div class='btn-group'>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users view')): ?>
                        <a href="<?php echo e(route('adminPanel.users.show', [$user->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                        <form action="<?php echo e(route('adminPanel.user.approve', [$user->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                        <button type="submit" class="btn btn-primary btn-sm" <?php echo e($user->approved_at ? 'disabled': ''); ?>>Approve</button>
                        </form>
                        
                        <?php endif; ?>
                    </div>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/users/table.blade.php ENDPATH**/ ?>