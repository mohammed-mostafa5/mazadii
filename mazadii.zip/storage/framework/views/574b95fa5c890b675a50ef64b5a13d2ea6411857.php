<!-- Photo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('photo', __('models/products.fields.photo').':'); ?>

    

    <input type="file" name="photo[]" class="form-control" multiple>
</div>


<ul class="nav nav-pills mb-1" id="pills-tab" role="tablist">

    <?php $__currentLoopData = config('langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li class="nav-item">
        <a class="nav-link <?php echo e(request('languages') == $locale ?'active':''); ?>" id="<?php echo e($name); ?>-tab" data-toggle="pill" href="#<?php echo e($name); ?>" role="tab" aria-controls="<?php echo e($name); ?>" aria-selected="<?php echo e(request('languages') == $locale  ? 'true' : 'false'); ?>"><?php echo e($name); ?></a>
    </li>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<div class="tab-content" id="pills-tabContent">

    <?php $__currentLoopData = config('langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="tab-pane fade <?php echo e(request('languages') == $locale ?'show active':''); ?>" id="<?php echo e($name); ?>" role="tabpanel" aria-labelledby="<?php echo e($name); ?>-tab">

        <!-- Name Field -->
        <div class="form-group col-sm-6">
            <?php echo Form::label('name', __('models/products.fields.name').':'); ?>

            <?php echo Form::text($locale . '[name]', isset($product)? $product->translate($locale)->name : '' , ['class'
            => 'form-control']); ?>

        </div>

        <!-- Description Field -->
        <div class="form-group col-sm-12 col-lg-6">
            <?php echo Form::label('description', __('models/products.fields.description').':'); ?>

            <?php echo Form::textarea($locale . '[description]', isset($product)? $product->translate($locale)->name : '' ,
            ['class' => 'form-control']); ?>

        </div>

    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Category Name Field -->
    <div class="form-group col-sm-6">
        <?php echo Form::label('name', __('models/products.fields.category_name').':'); ?>


        <select name="category_id" id="type" class="form-control">
            <option value="" class="text-secondary">Select Category</option>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($parent->id); ?>" <?php echo e(isset($product)? $product->category_id == $parent->id? 'selected' : '' : ''); ?>><?php echo e($parent->name); ?>

            </option>
            <?php if(isset($category->children)): ?>
            <?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($child->id); ?>" <?php echo e(isset($product)? $product->category_id == $child->id? 'selected' : '' : ''); ?>>-- <?php echo e($child->name); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </select>


    </div>



    <!-- Status Field -->
    <div class="form-group col-sm-6">
        <?php echo Form::label('status', __('models/categories.fields.status').':'); ?>


        <label class="radio-inline">
            <?php echo Form::radio('status', "1", 'active'); ?> active
        </label>

        <label class="radio-inline">
            <?php echo Form::radio('status', "0", null); ?> inactive
        </label>
    </div>

    <!-- start Price Field -->
    <div class="form-group col-sm-6">
        <?php echo Form::label('start_price', __('models/products.fields.start_price').':'); ?>

        <?php echo Form::number('start_price', null, ['class' => 'form-control start_price']); ?>

    </div>


    <br>
    <!-- Submit Field -->
    <div class="form-group col-sm-12">
        <?php echo Form::submit(__('crud.save'), ['class' => 'btn btn-primary']); ?>

        <a href="<?php echo e(route('adminPanel.products.index')); ?>" class="btn btn-default"><?php echo app('translator')->get('crud.cancel'); ?></a>
    </div>

    <script>

    </script>
<?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/products/fields.blade.php ENDPATH**/ ?>