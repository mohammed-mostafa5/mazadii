<div class="row">
    <?php echo $records->render(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\mazadii\vendor\infyomlabs\coreui-templates\src/../views/common/paginate.blade.php ENDPATH**/ ?>