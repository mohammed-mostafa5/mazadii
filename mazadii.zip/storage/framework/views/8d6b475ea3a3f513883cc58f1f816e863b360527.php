

<?php $__env->startSection('content'); ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo route('adminPanel.products.index'); ?>"><?php echo app('translator')->get('models/products.singular'); ?></a>
    </li>
    <li class="breadcrumb-item active"><?php echo app('translator')->get('crud.add_new'); ?></li>
</ol>
<div class="container-fluid">
    <div class="animated fadeIn">
        <?php echo $__env->make('coreui-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-plus-square-o fa-lg"></i>
                        <strong>Create <?php echo app('translator')->get('models/products.singular'); ?></strong>
                    </div>
                    <div class="card-body">
                        <?php echo Form::open(['route' => 'adminPanel.products.store', 'enctype' => 'multipart/form-data']); ?>


                        <?php echo $__env->make('adminPanel.products.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $( ".regular_price" ).keyup(function() {
        $( ".distributor_price" ).val($( this ).val());
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminPanel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/products/create.blade.php ENDPATH**/ ?>