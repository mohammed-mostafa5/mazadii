<div class="table-responsive-sm">
    <table class="table table-striped" id="products-table">
        <thead>
            <tr>
                <th>#</th>
                <th><?php echo app('translator')->get('models/products.fields.category_name'); ?></th>
                <th><?php echo app('translator')->get('models/products.fields.name'); ?></th>
                <th><?php echo app('translator')->get('models/products.fields.description'); ?></th>
                
                <th><?php echo app('translator')->get('models/products.fields.start_bid_price'); ?></th>
                <th><?php echo app('translator')->get('models/products.fields.status'); ?></th>
                <th><?php echo app('translator')->get('models/products.fields.photo'); ?></th>
                
                
                <th><?php echo app('translator')->get('crud.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->category->name ?? ''); ?></td>
                <td><?php echo e($product->name ?? ''); ?></td>
                <td><?php echo e(Str::limit($product->description ?? '',50) ?? ''); ?></td>
                <td><?php echo e($product->start_bid_price ?? ''); ?></td>
                <td><?php echo e($product->status ?? ''); ?></td>
                <td>
                    <img src="<?php echo e(asset('uploads/images/thumbnail/' . $product->first_photo)); ?>" alt="<?php echo e($product->name); ?>">
                </td>

                <td>
                    <a href="<?php echo e(route('adminPanel.products.show', [$product->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                    <?php echo Form::open(['route' => ['adminPanel.product.approve', $product->id], 'method' => 'patch', 'class' => 'd-inline']); ?>

                    <div class='btn-group'>
                        <?php echo Form::button('Approve', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/products/table.blade.php ENDPATH**/ ?>