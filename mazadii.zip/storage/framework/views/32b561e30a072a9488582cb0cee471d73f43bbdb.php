<div class="table-responsive-sm">
    <table class="table table-striped" id="sliders-table">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('models/metas.fields.language'); ?></th>
                <th><?php echo app('translator')->get('models/sliders.fields.photo'); ?></th>
                <th><?php echo app('translator')->get('models/sliders.fields.title'); ?></th>
                
                
                <th><?php echo app('translator')->get('models/sliders.fields.status'); ?></th>
                <th><?php echo app('translator')->get('models/sliders.fields.sort'); ?></th>
                <th colspan="3"><?php echo app('translator')->get('crud.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i = 1; ?>
            <?php $__currentLoopData = config('langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($name); ?></td>
                <td>
                    <?php if($i): ?>
                    <img src="<?php echo e(asset('uploads/images/thumbnail/' . $slider->photo)); ?>" alt="<?php echo e($slider->name); ?>"
                        style="width:40px">
                    <?php endif; ?>
                </td>
                <td><?php echo e($slider->translate($locale)->title); ?></td>
                
                <td><?php echo e($i ? $slider->status ? 'Active' : 'Inactive' : ''); ?></td>
                <td><?php echo e($i ? $slider->sort : ''); ?></td>


                <td>
                    <?php if($i): ?>
                        
                    <?php echo Form::open(['route' => ['adminPanel.sliders.destroy', $slider->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('adminPanel.sliders.show', [$slider->id])); ?>" class='btn btn-ghost-success'><i
                                class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('adminPanel.sliders.edit', [$slider->id])); ?>" class='btn btn-ghost-info'><i
                                class="fa fa-edit"></i></a>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn
                        btn-ghost-danger', 'onclick' => 'return confirm("'.__('crud.are_you_sure').'")']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                    <?php endif; ?>
                </td>
            </tr>

            <?php $i = 0; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/sliders/table.blade.php ENDPATH**/ ?>