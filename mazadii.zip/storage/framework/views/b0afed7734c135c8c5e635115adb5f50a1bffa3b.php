<div class="table-responsive-sm">
    <table class="table table-striped" id="categories-table">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('models/metas.fields.id'); ?></th>
                <th><?php echo app('translator')->get('models/metas.fields.language'); ?></th>
                <th><?php echo app('translator')->get('models/categories.fields.type'); ?></th>
                <th><?php echo app('translator')->get('models/categories.fields.name'); ?></th>
                <th><?php echo app('translator')->get('models/categories.fields.photo'); ?></th>
                <th><?php echo app('translator')->get('models/categories.fields.status'); ?></th>
                <th><?php echo app('translator')->get('crud.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i = 1;?>
            <?php $__currentLoopData = config('langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->id); ?></td>
                <td><?php echo e($name); ?></td>
                <td><?php echo e($i ? $category->parent_id == null ? 'Parent' : 'Child' : ''); ?></td>
                <td><?php echo e($category->translate($locale)->name); ?></td>
                <td>
                    <?php if($i): ?>
                    <img src="<?php echo e($category->photo_path); ?>" alt="<?php echo e($category->name); ?>">
                    <?php endif; ?>
                </td>
                <td><?php echo e($i ? $category->status ? 'Active' : 'Inactive' : ''); ?></td>

                <td>
                    <?php echo Form::open(['route' => ['adminPanel.categories.destroy', $category->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('adminPanel.categories.show', [$category->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('adminPanel.categories.edit', [$category->id]) . "?languages=$locale"); ?>" class='btn btn-ghost-info'><i class="fa fa-edit"></i></a>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn
                        btn-ghost-danger', 'onclick' => 'return confirm("'.__('crud.are_you_sure').'")']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>

            <?php $i = 0; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/categories/table.blade.php ENDPATH**/ ?>