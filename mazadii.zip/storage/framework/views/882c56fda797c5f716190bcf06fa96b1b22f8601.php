<div class="photos row">
    <!-- Photo Field -->
    <div class="form-group">
        <?php echo Form::label('photos', 'Photos : '); ?>

        <div class="product_photos p-3">
            <?php $__currentLoopData = $product->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(asset("uploads/images/thumbnail/$item->photo")); ?>" alt="<?php echo e($product->name); ?>" width="200" class="img-thumbnail">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Category Field -->
<div class="form-group show">
    <?php echo Form::label('category', __('models/products.fields.category_name').':'); ?>

    <span><?php echo e($product->category->name ?? ''); ?></span>
</div>


<!-- Name Field -->
<div class="form-group show">
    <?php echo Form::label('name', __('models/products.fields.name').':'); ?>

    <span><?php echo e($product->name); ?></span>
</div>

<!-- Description Field -->
<div class="form-group show">
    <?php echo Form::label('description', __('models/products.fields.description').':'); ?>

    <span><?php echo e($product->description); ?></span>
</div>


<!-- start_bid_price Field -->
<div class="form-group show">
    <?php echo Form::label('start_bid_price', __('models/products.fields.start_bid_price').':'); ?>

    <span><?php echo e($product->start_bid_price ?? ''); ?></span>
</div>


<!-- Created At Field -->
<div class="form-group show">
    <?php echo Form::label('created_at', __('models/products.fields.created_at').':'); ?>

    <span><?php echo e($product->created_at); ?></span>
</div>

<!-- Updated At Field -->
<div class="form-group show">
    <?php echo Form::label('updated_at', __('models/products.fields.updated_at').':'); ?>

    <span><?php echo e($product->updated_at); ?></span>
</div>




<div class=" clearfix"></div>
<?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/products/show_fields.blade.php ENDPATH**/ ?>