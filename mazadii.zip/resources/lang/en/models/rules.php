<?php

return array (
  'singular' => 'Rule',
  'plural' => 'Rules',
  'fields' => 
  array (
    'id' => 'Id',
    'title' => 'Title',
    'description' => 'Description',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
