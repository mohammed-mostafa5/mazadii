<?php

return array (
  'singular' => 'SiteOption',
  'plural' => 'SiteOptions',
  'fields' => 
  array (
    'id' => 'Id',
    'product_duration' => 'Product Duration',
    'deposit_percentage' => 'Deposit Percentage',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
