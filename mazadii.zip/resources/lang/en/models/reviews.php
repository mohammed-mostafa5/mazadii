<?php

return array(
    'singular' => 'Review',
    'plural' => 'Reviews',
    'fields' =>
    array(
        'id' => 'Id',
        'product' => 'Product',
        'user' => 'User',
        'comment' => 'Comment',
        'action' => 'Action',
    ),
);
