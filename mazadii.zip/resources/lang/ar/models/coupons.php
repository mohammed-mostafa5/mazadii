<?php

return array(
  'singular' => 'Coupon',
  'plural' => 'Coupons',
  'fields' =>
  array(
    'id' => 'Id',
    'code' => 'Code',
    'value' => 'Value',
    'status' => 'Status',
    'expired_at' => 'Expired At',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
