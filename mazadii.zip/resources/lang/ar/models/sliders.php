<?php

return array(
  'singular' => 'Slider',
  'plural' => 'Sliders',
  'fields' =>
  array(
    'id' => 'Id',
    'photo' => 'Photo',
    'title' => 'Title',
    'description' => 'Description',
    'button_text' => 'Button Text',
    'link' => 'Link',
    'status' => 'Status',
    'sort' => 'Sort',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
