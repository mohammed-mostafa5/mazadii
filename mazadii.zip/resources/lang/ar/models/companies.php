<?php

return array(
  'singular' => 'Company',
  'plural' => 'Companies',
  'fields' =>
  array(
    'id' => 'Id',
    'name' => 'Name',
    'user_name' => 'Username',
    'photo' => 'Photo',
    'attach' => 'Attachments',
    'address' => 'Address',
    'about' => 'About Company',
    'policies' => 'Company Policies',
    'status' => 'Status',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
