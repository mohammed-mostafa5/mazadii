<?php

return array (
  'singular' => 'Notification',
  'plural' => 'Notifications',
  'fields' => 
  array (
    'id' => 'Id',
    'title' => 'Title',
    'body' => 'Body',
    'send_to' => 'Send To',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
