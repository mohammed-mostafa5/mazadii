<?php

return array (
  'singular' => 'Roles',
  'plural' => 'Roles',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
  ),
);
