<?php

return array (
  'singular' => 'Article',
  'plural' => 'Articles',
  'fields' => 
  array (
    'id' => 'Id',
    'title' => 'Title',
    'body' => 'Body',
    'photo' => 'Photo',
    'status' => 'Status',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
