@component('mail::message')

# {{$data}}

Thanks,<br>
{{ config('app.name') }}
@endcomponent
