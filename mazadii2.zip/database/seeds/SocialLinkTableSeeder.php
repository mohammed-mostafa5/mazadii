<?php

use App\Models\SocialLink;
use Illuminate\Database\Seeder;

class SocialLinkTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $allData = [
        //     [ 'name' => 'facebook', 'link' => 'https://www.facebook.com/techvillageegypt', 'status' => 'Active', ],
        //     [ 'name' => 'twitter', 'link' => 'https://www.facebook.com/techvillageegypt', 'status' => 'Active', ],
        //     [ 'name' => 'linkedin', 'link' => 'https://www.facebook.com/techvillageegypt', 'status' => 'Inactive', ],
        //     [ 'name' => 'google-plus', 'link' => 'https://www.facebook.com/techvillageegypt', 'status' => 'Active', ],
        //     [ 'name' => 'youtube', 'link' => 'https://www.facebook.com/techvillageegypt', 'status' => 'Inactive', ],
        //     [ 'name' => 'instagram', 'link' => 'https://www.facebook.com/techvillageegypt', 'status' => 'Active', ],
        //     [ 'name' => 'pinterest', 'link' => 'https://www.facebook.com/techvillageegypt', 'status' => 'Inactive', ]
        // ];

        
        // foreach ($allData as $data) {
            
        //     SocialLink::create($data);
        // }
    }
}
