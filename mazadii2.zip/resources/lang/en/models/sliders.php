<?php

return array(
  'singular' => 'Slider',
  'plural' => 'Sliders',
  'fields' =>
  array(
    'id' => 'Id',
    'title' => 'Title',
    'photo' => 'Photo',
    'button_text' => 'Button Text',
    'content' => 'Content',
    'status' => 'Status',
    'in_order_to' => 'In Order To',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
    'description' => 'Description',
    'link' => 'Link',
    'sort' => 'Sort',
  ),
);
