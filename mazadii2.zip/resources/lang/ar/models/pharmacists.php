<?php

return array (
  'singular' => 'Pharmacist',
  'plural' => 'Pharmacists',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'syndicate_id' => 'Syndicate Id',
    'personal _id' => 'Personal  Id',
    'photo' => 'Photo',
    'status' => 'Status',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
