<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', __('models/roles.fields.id').':') !!}
    <p>{{ $roles->id }}</p>
</div>

<!-- Name Field -->
<div class="form-group">
    {!! Form::label('name', __('models/roles.fields.name').':') !!}
    <p>{{ $roles->name }}</p>
</div>

