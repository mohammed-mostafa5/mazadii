<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <?php echo $__env->make('adminPanel.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
    </nav>
    <!--<button class="sidebar-minimizer brand-minimizer" type="button"></button>-->
</div>
<?php /**PATH C:\xampp\htdocs\mazadii\resources\views/adminPanel/layouts/sidebar.blade.php ENDPATH**/ ?>