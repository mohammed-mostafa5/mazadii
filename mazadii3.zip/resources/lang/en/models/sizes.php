<?php

return array (
  'singular' => 'Size',
  'plural' => 'Sizes',
  'fields' => 
  array (
    'id' => 'Id',
    'text' => 'Text',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
