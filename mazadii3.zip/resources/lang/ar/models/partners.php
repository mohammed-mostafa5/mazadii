<?php

return array (
  'singular' => 'Partner',
  'plural' => 'Partners',
  'fields' => 
  array (
    'id' => 'Id',
    'photo' => 'Photo',
    'name' => 'Name',
    'link' => 'Link',
    'status' => 'Status',
  ),
);
